package com.example.asus.receitas;

import static org.junit.Assert.*;

/**
 * Created by vitorg on 17/11/17.
 */
public class MainActivityTest {

}